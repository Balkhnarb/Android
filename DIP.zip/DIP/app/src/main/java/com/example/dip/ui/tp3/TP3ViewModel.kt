package com.example.dip.ui.tp3

import androidx.lifecycle.ViewModel

class TP3ViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
