package com.example.dip

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import androidx.fragment.app.Fragment
import com.example.dip.ui.tp4.TP4Fragment
import com.example.dip.ui.tp4.fragments.Fragment1
import com.example.dip.ui.tp4.fragments.Fragment2
import com.example.dip.ui.tp4.fragments.Fragment3
import kotlinx.android.synthetic.main.t_p4_fragment.*
import kotlinx.android.synthetic.main.t_p4_fragment.view.*

class TP4 : AppCompatActivity() {

    private val frag1 = Fragment1()
    private val frag2 = Fragment2()
    private val frag3 = Fragment3()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.t_p4_fragment)

        appliquerFragment(frag1)

        bottom_nav.setOnNavigationItemSelectedListener{
            when(it.itemId) {
                R.id.frag1 -> appliquerFragment(frag1)
                R.id.frag2 -> appliquerFragment(frag2)
                R.id.frag3 -> appliquerFragment(frag3)
            }
            true
        }
    }

    private fun appliquerFragment(f:Fragment) =
        supportFragmentManager.beginTransaction().apply{
            replace(R.id.fl_wrapper,f)
            commit()
    }
}