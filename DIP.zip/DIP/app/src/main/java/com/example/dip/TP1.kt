package com.example.dip

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.example.dip.ui.tp1.TP1Fragment

class TP1 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.t_p1_fragment)

    }

    fun clickConnection(view: View) {
        Toast.makeText(this,"Bonjour",Toast.LENGTH_SHORT).show()
    }
}
