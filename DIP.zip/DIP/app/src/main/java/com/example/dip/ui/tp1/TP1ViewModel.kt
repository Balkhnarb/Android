package com.example.dip.ui.tp1

import androidx.lifecycle.ViewModel

class TP1ViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
