package com.example.dip.ui.tp2

import androidx.lifecycle.ViewModel

class TP2ViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
