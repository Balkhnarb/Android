package com.example.dip.ui.tp4

import androidx.lifecycle.ViewModel

class TP4ViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}