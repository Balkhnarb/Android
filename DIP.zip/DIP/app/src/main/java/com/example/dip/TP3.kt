package com.example.dip

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.dip.ui.tp3.TP3Fragment
import kotlinx.android.synthetic.main.t_p3_fragment.*
import kotlinx.android.synthetic.main.t_p3_fragment.view.*

class TP3 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.t_p3_fragment)
    }

    fun clickConnection(view: View) {
        textView12.visibility = View.VISIBLE
    }
}
