package com.example.dip

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.t_p1_fragment.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun ouvrirTP1(view: View) {
        var tp1 = Intent(this,TP1::class.java)
        startActivity(tp1)
    }

    fun ouvrirTP2(view: View) {
        var tp2 = Intent(this,TP2::class.java)
        startActivity(tp2)
    }

    fun ouvrirTP3(view: View) {
        var tp3 = Intent(this,TP3::class.java)
        startActivity(tp3)
    }

    fun ouvrirTP4(view: View) {
        var tp4 = Intent(this,TP4::class.java)
        startActivity(tp4)
    }
}
