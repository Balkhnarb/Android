package com.example.dip

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.dip.ui.tp2.TP2Fragment

class TP2 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.t_p2_fragment)
    }
}
